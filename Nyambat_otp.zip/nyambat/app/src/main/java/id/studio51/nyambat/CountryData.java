package id.studio51.nyambat;

public class CountryData {
    public static final String[] countryNames = {"Indonesia", "Malaysia",
            "Singapore"};

    public static final String[] countryAreaCodes = {"62", "60",
            "65"};
}